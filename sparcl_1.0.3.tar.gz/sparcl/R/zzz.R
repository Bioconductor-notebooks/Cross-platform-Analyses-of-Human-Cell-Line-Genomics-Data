 .onLoad <- function(lib,pkg){
  library.dynam("sparcl",pkg,lib)
}
